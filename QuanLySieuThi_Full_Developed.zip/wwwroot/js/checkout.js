(() => {
    const checkout = document.querySelector("#checkout");
    if (!checkout) return;

    const search = document.querySelector("#catalog-search");
    const message = document.querySelector("#catalog-message");
    const rows = Array.from(checkout.querySelectorAll("[data-product]"));
    const payment = document.querySelector("#payment");
    const promotion = document.querySelector("#promotion");
    const cashFields = document.querySelector("#cash-payment-fields");
    const cashReceived = document.querySelector("#cash-received");
    const cashChange = document.querySelector("#cash-change");
    const hint = document.querySelector("#payment-hint");
    const money = value => new Intl.NumberFormat("vi-VN", {
        style: "currency", currency: "VND", maximumFractionDigits: 0
    }).format(Math.max(0, value || 0));

    function calculate() {
        const isMomo = payment.value === "MoMo";
        let subtotal = 0;
        for (const row of rows) {
            const quantity = Number(row.querySelector("input[type=number]").value) || 0;
            const price = Number(row.dataset.price) || 0;
            subtotal += isMomo ? Math.round(price * quantity) : Math.round(price * quantity * 100) / 100;
        }

        let discount = 0;
        const selected = promotion.selectedOptions[0];
        if (selected && selected.value) {
            const value = Number(selected.dataset.value) || 0;
            if (selected.dataset.type === "Percent") discount = subtotal * value / 100;
            if (selected.dataset.type === "Fixed") discount = value;
            discount = Math.min(subtotal, isMomo ? Math.round(discount) : Math.round(discount * 100) / 100);
        }
        const total = Math.max(0, subtotal - discount);
        document.querySelector("#preview-subtotal").textContent = money(subtotal);
        document.querySelector("#preview-discount").textContent = money(discount);
        document.querySelector("#preview-total").textContent = money(total);

        cashFields.hidden = isMomo;
        cashReceived.disabled = isMomo;
        cashReceived.required = !isMomo;
        const received = Number(cashReceived.value) || 0;
        const change = Math.max(0, received - total);
        cashChange.textContent = money(change);
        hint.textContent = isMomo
            ? "Đơn hàng sẽ được giữ tồn kho trong khi chờ xác nhận thanh toán MoMo."
            : received < total
                ? `Còn thiếu ${money(total - received)}.`
                : "Số tiền khách đưa đã đủ để thanh toán.";
        hint.classList.toggle("text-danger", !isMomo && received < total);
        hint.classList.toggle("text-success", !isMomo && received >= total);
        return { total, received, isMomo };
    }

    search.addEventListener("input", () => {
        const term = search.value.trim().toLowerCase();
        for (const row of rows) {
            const matches = Object.values(row.dataset).some(value => value.toLowerCase().includes(term));
            row.hidden = !matches && !Number(row.querySelector("input[type=number]").value);
        }
        message.textContent = "";
    });

    search.addEventListener("keydown", event => {
        if (event.key !== "Enter") return;
        event.preventDefault();
        const term = search.value.trim().toLowerCase();
        if (!term) return;

        const row = rows.find(item => item.dataset.barcode?.toLowerCase() === term)
            ?? rows.find(item => item.dataset.sku.toLowerCase() === term);
        if (!row) {
            message.textContent = "Mã hàng không tồn tại hoặc hết tồn khả dụng.";
            return;
        }

        const quantity = row.querySelector("input[type=number]");
        const next = Number(quantity.value) + 1;
        if (next > Number(quantity.max)) {
            message.textContent = "Không đủ tồn khả dụng.";
            return;
        }
        quantity.value = next.toFixed(3);
        search.value = "";
        search.dispatchEvent(new Event("input"));
        message.textContent = `Đã thêm ${row.dataset.name}.`;
        calculate();
    });

    for (const row of rows) {
        row.querySelector("input[type=number]").addEventListener("input", calculate);
    }
    payment.addEventListener("change", calculate);
    promotion.addEventListener("change", calculate);
    cashReceived.addEventListener("input", calculate);

    checkout.addEventListener("submit", event => {
        const { total, received, isMomo } = calculate();
        let index = 0;
        for (const row of rows) {
            const quantity = row.querySelector("input[type=number]");
            quantity.removeAttribute("name");
            row.querySelector("input[type=hidden]")?.remove();
            if (!Number(quantity.value)) continue;

            const productId = document.createElement("input");
            productId.type = "hidden";
            productId.name = `Lines[${index}].ProductId`;
            productId.value = row.dataset.product;
            quantity.name = `Lines[${index}].Quantity`;
            quantity.after(productId);
            index++;
        }
        if (!index) {
            event.preventDefault();
            message.textContent = "Chọn ít nhất một sản phẩm.";
            search.focus();
            return;
        }
        if (!isMomo && received < total) {
            event.preventDefault();
            message.textContent = "Tiền khách đưa chưa đủ thanh toán.";
            cashReceived.focus();
        }
    });

    calculate();
})();
