# Hướng dẫn nâng cấp và chạy Quản lý siêu thị mini

## 1. Chuẩn bị

Cài đặt:
- .NET 9 SDK
- SQL Server Express hoặc SQL Server Developer
- SQL Server Management Studio (SSMS) hoặc `sqlcmd`
- Visual Studio 2022 có workload ASP.NET and web development, hoặc Visual Studio Code

Kiểm tra SDK trong PowerShell:

```powershell
dotnet --list-sdks
```

Giải nén `QuanLySieuThi_Full_Developed.zip` vào một thư mục, ví dụ `C:\QuanLySieuThi`.

## 2. Nếu đang dùng cơ sở dữ liệu cũ

**Sao lưu database trước khi cập nhật.** Mở PowerShell tại thư mục dự án và chạy:

```powershell
sqlcmd -S '.\SQLEXPRESS' -E -C -b -d QuanLySieuThiDb -i CoSoDuLieu/08_AddCashPaymentAndReceipt.sql
```

Nếu SQL Server của bạn dùng instance khác, thay `'.\SQLEXPRESS'` bằng tên instance đang dùng.

Script này thêm hai cột tiền khách đưa và tiền thừa. Với hóa đơn cũ, hệ thống đặt mặc định tiền khách đưa bằng tổng thanh toán và tiền thừa bằng 0 vì phiên bản trước không lưu số tiền thực nhận.

## 3. Nếu tạo cơ sở dữ liệu mới

Chạy lần lượt:

```powershell
sqlcmd -S '.\SQLEXPRESS' -E -C -b -i CoSoDuLieu/01_CreateDatabase.sql
sqlcmd -S '.\SQLEXPRESS' -E -C -b -d QuanLySieuThiDb -i CoSoDuLieu/03_DemoData.sql
```

Nếu muốn chạy bản demo tự động, có thể dùng bước 4; script demo tự tạo database riêng và cập nhật schema.

## 4. Chạy demo bằng một lệnh

Từ thư mục gốc dự án:

```powershell
pwsh -File LenhChay/Start-Demo.ps1
```

Script sử dụng SQL Server Express (`.\SQLEXPRESS`), tạo database demo riêng `QuanLySieuThi_Demo_Local`, cập nhật schema, nạp dữ liệu mẫu và chạy website tại:

`http://localhost:5233/Auth/Login`

Lần đầu chạy, nhập mật khẩu Admin khi PowerShell yêu cầu. Hãy dùng mật khẩu riêng của bạn.

Nếu chưa có PowerShell 7 (`pwsh`), có thể chạy thủ công theo bước 5.

## 5. Chạy thủ công

Mở PowerShell tại thư mục dự án:

```powershell
$env:ConnectionStrings__DefaultConnection = 'Server=.\SQLEXPRESS;Database=QuanLySieuThiDb;Integrated Security=true;TrustServerCertificate=true'
$env:BootstrapAdmin__Username = 'admin'
$env:BootstrapAdmin__Password = Read-Host 'Nhap mat khau Admin' -MaskInput

dotnet restore
dotnet build QuanLySieuThi.csproj -c Release
dotnet run --project QuanLySieuThi.csproj --launch-profile http
```

Mở địa chỉ mà ứng dụng hiển thị trong terminal. Với cấu hình mặc định, trang đăng nhập là:

`http://localhost:5233/Auth/Login`

Sau lần tạo Admin đầu tiên, xóa biến mật khẩu khỏi phiên PowerShell:

```powershell
Remove-Item Env:BootstrapAdmin__Password
```

## 6. Chạy bằng Visual Studio

1. Mở `quanlysieuthi.sln`.
2. Chọn cấu hình `Debug` hoặc `Release`.
3. Đặt connection string và biến bootstrap Admin trong biến môi trường chạy ứng dụng.
4. Build Solution.
5. Nhấn `F5` để chạy.
6. Mở trang `/Auth/Login`.

Không đưa mật khẩu Admin, mật khẩu SQL hoặc khóa MoMo vào GitHub hay file cấu hình được commit.

## 7. Kiểm tra luồng bán hàng và in hóa đơn

1. Đăng nhập bằng Admin.
2. Vào **Nhân viên & tài khoản**, tạo tài khoản thu ngân nếu chưa có.
3. Vào **Sản phẩm**, kiểm tra sản phẩm đang hoạt động và có tồn kho.
4. Đăng nhập bằng tài khoản thu ngân.
5. Mở **Bán hàng**, nhập mã SKU/mã vạch hoặc tìm sản phẩm.
6. Nhập số lượng, chọn khách hàng/khuyến mãi nếu cần.
7. Chọn **Tiền mặt**, nhập tiền khách đưa. Hệ thống hiển thị tiền thừa và kiểm tra lại ở máy chủ.
8. Nhấn **Hoàn tất thanh toán**.
9. Ở trang chi tiết hóa đơn, nhấn **In hóa đơn**. Chọn máy in nhiệt hoặc **Save as PDF** trong hộp thoại in.
10. Có thể in lại hóa đơn đã hoàn tất từ trang **Hóa đơn**.

Hóa đơn chưa thanh toán thành công không được in dưới dạng hóa đơn hoàn tất.

## 8. MoMo

Thanh toán MoMo chỉ hoạt động khi đã cấu hình thông tin merchant và URL HTTPS công khai. Xem mục **Thanh toán MoMo** trong `README.md`. Nếu chưa cấu hình, dùng thanh toán tiền mặt để kiểm tra POS.

## 9. Kiểm thử

Sau khi chạy ứng dụng và đã có dữ liệu QA, xem `KiemThu/README` nếu có hoặc chạy bộ smoke test hiện có:

```powershell
pwsh ./KiemThu/Smoke.ps1 -BaseUrl http://localhost:5233
```

Lưu ý: smoke test tạo giao dịch thật trên database đang cấu hình. Nên chạy trên database kiểm thử, không chạy trực tiếp trên dữ liệu cửa hàng thật.
